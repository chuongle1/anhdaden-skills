# Cybersecurity Expert Skills (Advanced)

A portable, evidence-driven cybersecurity skill library for **Claude Code and Claude Web**.

## What is included

- 18 focused skills with YAML frontmatter and task-specific workflows.
- Shared global operating rules in `CLAUDE.md`.
- Reusable references: authorization, evidence handling, methodology, secure coding, CVSS, OWASP, ATT&CK, cloud/Kubernetes, and AI/LLM security.
- Offline helper scripts for evidence hashing, finding validation, and safe secret redaction.
- Templates for rules of engagement, findings, pentest reports, incident timelines, detection engineering, threat models, and code review.

## Skill inventory (18)

| Group | Skills |
|---|---|
| Core | `security-core`, `security-code-engineering`, `security-assessment-reporting` |
| Offensive | `pentest-web-api`, `pentest-network-infrastructure`, `red-team-operations`, `vulnerability-research`, `malware-reverse-engineering` |
| Defensive | `soc-analyst`, `incident-response`, `detection-engineering`, `threat-hunting`, `threat-intelligence` |
| Engineering | `appsec-code-review`, `cloud-kubernetes-security`, `devsecops-automation`, `security-architecture`, `ai-llm-security` |

Cloud Security and Kubernetes Security are combined in `cloud-kubernetes-security` to retain both domains while keeping the requested total at 18.

## Install

### Claude Code
1. Copy `claude-code/.claude/skills/` into your repository's `.claude/skills/` directory, or copy the contents into your existing `.claude/skills/`.
2. Copy `CLAUDE.md` to the repository root (merge with existing instructions rather than overwriting user content).
3. Keep references and scripts in the package root or copy `references/`, `scripts/`, and `templates/` into your repository. Skill files refer to these paths relative to the project root when useful.
4. Restart the Claude Code session if skills are not immediately discovered.

### Claude Web
1. Open Claude's Customize/Capabilities area and locate Skills (the exact UI label can vary by plan and product version).
2. Upload each skill as its own ZIP: `claude-web/skills/<skill-name>.zip`.
3. Add the contents of `CLAUDE.md` to Project Instructions for the project where you use these skills.
4. Upload reference documents/templates as Project Knowledge when useful. Claude Web may not automatically load local scripts; ask Claude to inspect or recreate the helper workflow in an enabled analysis/code environment.

The package intentionally keeps the skills in the standard `SKILL.md` folder format. UI availability and upload limits are controlled by Anthropic and can change.

## Usage examples

- "Review this repository for authentication and authorization flaws. Use `appsec-code-review` and `security-assessment-reporting`."
- "Plan an authorized API assessment using the supplied scope. Use `pentest-web-api`; do not send destructive requests."
- "Triage these EDR alerts and build an evidence-backed incident timeline. Use `soc-analyst` and `incident-response`."
- "Create a Sigma detection for the behavior described, include false-positive analysis and tests. Use `detection-engineering`."
- "Threat-model this LLM agent, including indirect prompt injection and tool abuse. Use `ai-llm-security`."

## Safety model

The skills support authorized security work. They do not grant authorization. Active testing, exploitation, persistence, credential access, evasion, or impact simulation must remain within explicit written scope and agreed rules of engagement. Prefer non-destructive validation and stop when scope or authorization is unclear.

## Scripts

```bash
python3 scripts/validate_findings.py templates/examples/findings.example.json
python3 scripts/hash_evidence.py /path/to/evidence --output evidence-manifest.sha256
python3 scripts/redact_secrets.py input.log --output redacted.log
```

All scripts are offline. Review outputs before sharing; redaction is heuristic and cannot guarantee removal of every secret.

## Versioning and maintenance

- Version: 1.0.0
- Profile: Advanced
- Targets: Claude Code + Claude Web
- Review standards and external references periodically; standards evolve.
