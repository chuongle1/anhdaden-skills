# [ID] Finding title

- Severity / rationale:
- Confidence:
- Status:
- Asset / component / version:
- Location (endpoint, file:line, resource):
- CWE/CVE (verified only):
- First observed / last verified:

## Summary
What is wrong and why it matters.

## Preconditions
Attacker capability, identity/role, network position, configuration, and user interaction.

## Evidence
Evidence IDs, sanitized request/response/log/source excerpt, timestamps, hashes.

## Reproduction
1. Preconditions.
2. Minimal safe steps.
3. Expected result.
4. Actual result.

## Impact
Technical impact and realistic business impact.

## Root cause
Underlying design or implementation flaw.

## Remediation
Primary fix, defense-in-depth, owner, priority.

## Validation
Regression test and acceptance criteria.

## References
Authoritative sources.
