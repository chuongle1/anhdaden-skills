# Secure Code Review

- Repository / commit:
- Languages/frameworks:
- Review scope:
- Files/components inspected:
- Tests/tools and versions:
- Limitations:

## Architecture and trust boundaries

## Findings
Use `finding-template.md` for each confirmed issue.

## Uncertain observations
State evidence needed to confirm or dismiss.

## Security controls observed

## Recommended fixes and regression tests

## Validation status
Commands run and actual outcomes.
