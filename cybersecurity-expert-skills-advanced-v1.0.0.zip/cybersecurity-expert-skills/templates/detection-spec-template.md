# Detection Specification

- Name / ID / version / owner:
- Status / severity / confidence:
- Threat hypothesis:
- ATT&CK mapping (evidence-based):
- Data sources and required fields:
- Query/rule:
- Time window and aggregation:
- Positive test cases:
- Negative/benign test cases:
- Expected results:
- Known false positives and tuning:
- Triage steps:
- Telemetry health checks:
- Deployment / rollback:
- Metrics and review date:
