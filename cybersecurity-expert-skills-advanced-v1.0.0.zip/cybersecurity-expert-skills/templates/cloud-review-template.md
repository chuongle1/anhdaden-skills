# Cloud / Kubernetes Review

- Provider / account / region:
- Cluster / namespace:
- Read-only or approved write scope:
- Tool versions / timestamp:

## Identity and access
Roles, workload identities, privilege boundaries, key lifecycle.

## Network and exposure
Ingress, egress, segmentation, public endpoints, private links.

## Data and secrets
Storage permissions, encryption, KMS, secret references, retention.

## Workloads and supply chain
Images/digests, signatures, SBOM, runtime settings, admission policies.

## Audit and detection
Control-plane logs, runtime signals, retention, alerting.

## Findings and attack paths
Use the finding template.

## Remediation and verification
Priorities, owners, commands/tests, residual risks.
