# Incident Report

- Incident ID:
- Commander / owner:
- Severity:
- Start / detected / contained / recovered (UTC):
- Status:

## Executive summary
Confirmed facts, impact, and current state.

## Scope and affected assets
Systems, identities, data classes, regions, third parties.

## Timeline
UTC timestamp, event, source, evidence ID, confidence.

## Detection and analysis
Initial signal, pivots, hypotheses, validation, telemetry gaps.

## Containment / eradication / recovery
Action, approver, timestamp, impact, rollback, verification.

## Impact and notification
Availability, confidentiality, integrity, legal/privacy assessment and decision owner.

## Root cause and contributing factors

## Lessons learned and action tracker
Action, owner, priority, due date, acceptance test.
