# Rules of Engagement

## Engagement
- Client / authorizing owner:
- Engagement lead / emergency contact:
- Objective and success criteria:
- Start/end (include timezone):
- Environments:

## In-scope assets
- Domains/IPs/accounts/projects/clusters:
- Test identities and roles:
- Source IPs:

## Out of scope
- Explicit exclusions:
- Third-party systems:
- Sensitive/safety-critical systems:

## Permitted methods
- Passive discovery:
- Active scanning and rate limits:
- Authenticated testing:
- Exploit validation:
- Social engineering:
- Data access/handling:
- Cloud/Kubernetes actions:

## Prohibited actions
- DoS/load testing:
- Destructive changes:
- Persistence/lateral movement:
- Credential harvesting:
- Real data exfiltration:
- Other:

## Operations
- Approved time windows:
- Notification/escalation:
- Stop conditions:
- Evidence retention and transfer:
- Cleanup and rollback:
- Written approvals:
