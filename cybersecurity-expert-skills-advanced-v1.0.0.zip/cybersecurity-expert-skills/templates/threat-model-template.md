# Threat Model

## System context
Purpose, users, assets, data classes, deployment, integrations.

## Data flows and trust boundaries
Describe or attach diagram. Mark untrusted inputs and privileged operations.

## Security assumptions
Identity, network, runtime, provider, operational assumptions.

## Threat register
| ID | Asset / flow | Threat scenario | Preconditions | Impact | Existing controls | Gap | Mitigation | Owner |
|---|---|---|---|---|---|---|---|---|

## Abuse cases
Misuse paths, attacker goals, and control failures.

## Residual risks
Risk, rationale, owner, expiry/review date.

## Verification plan
Tests, telemetry, acceptance criteria.
