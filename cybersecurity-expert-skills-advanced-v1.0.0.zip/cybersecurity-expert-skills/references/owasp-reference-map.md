# OWASP Reference Map
Use current official versions and verify release dates before citing.
- Web Security Testing Guide (WSTG): structured web testing methodology.
- Application Security Verification Standard (ASVS): testable application security requirements.
- API Security Top 10: API-specific risk categories; use as a taxonomy, not a complete test plan.
- Cheat Sheet Series: implementation guidance for common controls.
- Top 10 for LLM Applications: AI/LLM threat taxonomy; supplement with system-specific threat modeling.
Official entry points: https://owasp.org/www-project-web-security-testing-guide/ ; https://owasp.org/www-project-application-security-verification-standard/ ; https://owasp.org/www-project-api-security/ ; https://owasp.org/www-project-top-10-for-large-language-model-applications/
