# Incident Evidence Checklist
Record incident ID, system/tenant, owner, UTC/timezone, collector, acquisition method, tool/version, hashes, source/destination, chain-of-custody events, storage access controls, and known gaps. Preserve volatile evidence when authorized and operationally safe. Document containment changes separately from original evidence.
