# Security Assessment Methodology
Use a repeatable lifecycle: scope → asset/context mapping → hypothesis → least-invasive validation → impact/confidence assessment → remediation → retest → report.
Maintain a coverage matrix. For each test, record objective, target, preconditions, method, evidence ID, result, and limitations. Negative results are bounded by coverage, test data, identity/role, environment, and time window.
