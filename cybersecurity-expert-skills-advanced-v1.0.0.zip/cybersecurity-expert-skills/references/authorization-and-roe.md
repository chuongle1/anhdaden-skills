# Authorization and Rules of Engagement
A valid engagement record should identify authorizing organization/person, owner, exact assets, exclusions, dates/timezone, permitted techniques, prohibited actions, test identities, source IPs, rate limits, data handling, third-party approvals, notification contacts, emergency stop process, and cleanup requirements.
A vague statement such as "test our website" is insufficient for intrusive testing. If scope is unclear, restrict work to passive review or prepare a proposed test plan.
