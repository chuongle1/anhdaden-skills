# Cloud and Kubernetes Checklist
Cloud: IAM least privilege, workload identity, short-lived credentials, private endpoints, segmentation, encryption, KMS policy, audit logs, backup/recovery, storage access, metadata protections, image provenance.
Kubernetes: API server exposure/RBAC/audit, Pod Security, non-root, read-only root FS, capabilities drop, seccomp, resource limits, NetworkPolicy, secrets encryption/access, admission controls, signed images, node hardening, runtime detection, namespace isolation.
Validate actual enforcement; a manifest setting alone does not prove runtime behavior.
