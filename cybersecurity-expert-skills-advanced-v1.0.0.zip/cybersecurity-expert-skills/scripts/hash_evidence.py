#!/usr/bin/env python3
"""Create a SHA-256 manifest for files under a path; does not modify evidence."""
from __future__ import annotations
import argparse, hashlib
from pathlib import Path

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("path", type=Path)
    ap.add_argument("--output", type=Path, default=Path("evidence-manifest.sha256"))
    args = ap.parse_args()
    target = args.path.resolve()
    if not target.exists():
        ap.error(f"path does not exist: {target}")
    files = [target] if target.is_file() else sorted(p for p in target.rglob("*") if p.is_file() and not p.is_symlink())
    lines = [f"{sha256(p)}  {p.relative_to(target.parent if target.is_file() else target)}" for p in files]
    args.output.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    print(f"Wrote {len(lines)} entries to {args.output}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
