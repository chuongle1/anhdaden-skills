#!/usr/bin/env python3
"""Validate the basic structure and required fields of a findings JSON document."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

REQUIRED = {"id", "title", "severity", "confidence", "status", "asset", "impact", "remediation"}
SEVERITIES = {"Critical", "High", "Medium", "Low", "Informational"}
CONFIDENCE = {"High", "Medium", "Low"}
STATUSES = {"confirmed", "needs-validation", "accepted-risk", "fixed", "retest-passed"}

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("file", type=Path)
    args = ap.parse_args()
    try:
        data = json.loads(args.file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: cannot read valid JSON: {exc}", file=sys.stderr)
        return 2
    findings = data.get("findings") if isinstance(data, dict) else None
    if not isinstance(findings, list):
        print("ERROR: top-level 'findings' must be an array", file=sys.stderr)
        return 2
    errors = []
    seen = set()
    for i, item in enumerate(findings):
        prefix = f"findings[{i}]"
        if not isinstance(item, dict):
            errors.append(f"{prefix}: must be an object")
            continue
        missing = sorted(REQUIRED - item.keys())
        if missing:
            errors.append(f"{prefix}: missing {', '.join(missing)}")
        fid = item.get("id")
        if fid in seen:
            errors.append(f"{prefix}: duplicate id {fid!r}")
        if fid:
            seen.add(fid)
        if item.get("severity") not in SEVERITIES:
            errors.append(f"{prefix}: invalid severity")
        if item.get("confidence") not in CONFIDENCE:
            errors.append(f"{prefix}: invalid confidence")
        if item.get("status") not in STATUSES:
            errors.append(f"{prefix}: invalid status")
        for field in ("title", "asset", "impact", "remediation"):
            if field in item and (not isinstance(item[field], str) or not item[field].strip()):
                errors.append(f"{prefix}: {field} must be a non-empty string")
    if errors:
        for err in errors:
            print(f"ERROR: {err}", file=sys.stderr)
        return 1
    print(f"OK: validated {len(findings)} finding(s)")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
