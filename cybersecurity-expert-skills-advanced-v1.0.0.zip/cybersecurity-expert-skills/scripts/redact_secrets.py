#!/usr/bin/env python3
"""Heuristically redact common secret patterns from text. Review output manually."""
from __future__ import annotations
import argparse, re
from pathlib import Path

PATTERNS = [
    (re.compile(r"(?i)(authorization\s*:\s*bearer\s+)[A-Za-z0-9._~+/=-]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)((?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|password|passwd|secret)\s*[=:]\s*)['\"]?[^'\"\s,;]+"), r"\1[REDACTED]"),
    (re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "[REDACTED_AWS_ACCESS_KEY]"),
    (re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"), "[REDACTED_PRIVATE_KEY]"),
]
def redact(text: str) -> str:
    for pattern, replacement in PATTERNS:
        text = pattern.sub(replacement, text)
    return text

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("input", type=Path)
    ap.add_argument("--output", type=Path)
    args = ap.parse_args()
    content = args.input.read_text(encoding="utf-8", errors="replace")
    result = redact(content)
    if args.output:
        args.output.write_text(result, encoding="utf-8")
        print(f"Wrote redacted text to {args.output}")
    else:
        print(result, end="")
    print("WARNING: heuristic redaction is incomplete; manually review before sharing.", file=__import__("sys").stderr)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
