# Helper scripts

All scripts are offline and use only the Python standard library.

- `hash_evidence.py`: computes SHA-256 for files and writes a manifest. It does not alter source files.
- `validate_findings.py`: checks required fields/enums in a JSON findings file. It is a structural check, not a severity or truth validator.
- `redact_secrets.py`: heuristic redaction for common token/key patterns. It is not comprehensive; manually inspect the output.

Run `python3 scripts/<script>.py --help` for options.
